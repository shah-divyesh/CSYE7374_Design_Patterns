package neu.csye7374.src;

public abstract class AbstractFirmStockFactory {
	public abstract StockAPI getObject(String iD, double price, String description, double bid, String tradeType);
}
