package neu.csye7374.src;

public class DeliveryFimStockSingletonFactory extends AbstractFirmStockFactory{
	
	
	private static DeliveryFimStockSingletonFactory instance;
	
	private DeliveryFimStockSingletonFactory() {
		super();
		instance=null;
	}
	
	public static synchronized DeliveryFimStockSingletonFactory getInstance() {
		if (instance == null) {
			instance = new DeliveryFimStockSingletonFactory();
		}
		return instance;
	}
	
	@Override
	public StockAPI getObject(String ID, double price, String description, double bid, String tradeType) {
		// TODO Auto-generated method stub
		return new DeliveryFirmStocks(ID,price,description,bid,tradeType);
	}

}
