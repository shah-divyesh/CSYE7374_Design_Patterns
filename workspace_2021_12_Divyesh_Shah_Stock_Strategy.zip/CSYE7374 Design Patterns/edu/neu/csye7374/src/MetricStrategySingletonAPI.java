package neu.csye7374.src;

public interface MetricStrategySingletonAPI {
	int calculateMetric();
}
