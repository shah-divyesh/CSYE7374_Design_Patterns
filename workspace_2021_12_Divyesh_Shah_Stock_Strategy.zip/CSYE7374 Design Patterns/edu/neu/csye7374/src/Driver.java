package neu.csye7374.src;


public class Driver {

	public static void main(String[] args) {
		StockMarket.demo();
	}
}


//Stocks: 
//Stock Market Now...
//TradedStocks: 
//Traded stocks Now...
//First display of stock market
//Stock Market Now...
//StockID: United Postal Service, price: 230.0, Metric: -23, description: UPS Common Stock
//StockID: Fedex, price: 178.5, Metric: 1, description: Fedex Common Stock
//StockID: DHL Group, price: 97.5, Metric: 36, description: DHL Common Stock
//StockID: AutoDesk, price: 170.0, Metric: 6, description: AutoDesk Common Share
//StockID: Adobe, price: 444.63, Metric: -6, description: Fedex Common Stock
//StockID: Corel, price: 510.5, Metric: -17, description: Corel Common Stock
//--------------------------------------------------------------------
//Bidding on DeliveryFirmStocks: United Postal Service 230.0
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//Bidding on DeliveryFirmStocks: United Postal Service 276.77467783172796
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//Bidding on DeliveryFirmStocks: United Postal Service 296.4499660875503
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//Bidding on DeliveryFirmStocks: United Postal Service 343.9244404445801
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//Bidding on DeliveryFirmStocks: United Postal Service 359.1245760943789
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//Bidding on DeliveryFirmStocks: United Postal Service 360.497869240059
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//
//--------------------------------------------------------------------
//Bidding on SoftwareFirmStocks: Fedex 164.81723278343227
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.69
//
//Bidding on SoftwareFirmStocks: Fedex 158.94944839760757
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.708
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.709
//
//Bidding on SoftwareFirmStocks: Fedex 165.15431751302395
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.71
//
//Bidding on SoftwareFirmStocks: Fedex 142.47744508978673
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.71
//
//Bidding on SoftwareFirmStocks: Fedex 133.62130404788624
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.71
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.711
//
//Bidding on SoftwareFirmStocks: Fedex 131.33555725850124
//After trade on SoftwareFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.711
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.712
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.712
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.712
//
//--------------------------------------------------------------------
//Bidding on DeliveryFirmStocks: DHL Group 108.7822653187794
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.713
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.714
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.714
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.714
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.714
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.714
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.714
//
//Bidding on DeliveryFirmStocks: DHL Group 102.23680810723252
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.714
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.715
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.715
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.715
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.715
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.716
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.716
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.716
//
//Bidding on DeliveryFirmStocks: DHL Group 105.11595898533326
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.716
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.716
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.716
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.716
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.716
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.716
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.716
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.717
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.717
//
//Bidding on DeliveryFirmStocks: DHL Group 115.55983387261233
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.717
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.717
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.717
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.717
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.718
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.718
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.718
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.718
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.718
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.718
//
//Bidding on DeliveryFirmStocks: DHL Group 93.24074807700903
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.719
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.719
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.719
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.719
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.719
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.719
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.719
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.719
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.719
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.72
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.72
//
//Bidding on DeliveryFirmStocks: DHL Group 107.81747332370361
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.72
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.721
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.721
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.721
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.721
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.721
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.721
//
//--------------------------------------------------------------------
//Bidding on DeliveryFirmStocks: AutoDesk 171.21580179019261
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.723
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.723
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.723
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.723
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.724
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.724
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.724
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.724
//
//Bidding on DeliveryFirmStocks: AutoDesk 122.7519419224012
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.725
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.725
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.725
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.725
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.725
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.725
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.725
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.725
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.726
//
//Bidding on DeliveryFirmStocks: AutoDesk 123.0
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.726
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.726
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.726
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.727
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.727
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.727
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.727
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.727
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.727
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.727
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.728
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.728
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.728
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.728
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.728
//
//Bidding on DeliveryFirmStocks: AutoDesk 149.54823842194733
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.728
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.729
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.729
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.729
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.729
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.729
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.729
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.73
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.73
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.73
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.73
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.73
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.73
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.73
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.73
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.73
//
//Bidding on DeliveryFirmStocks: AutoDesk 99.92259691124823
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.73
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.73
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.73
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.731
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.731
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.731
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.732
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.732
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.732
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.732
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.732
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.732
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.732
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.732
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.732
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.732
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.732
//
//Bidding on DeliveryFirmStocks: AutoDesk 54.760005761088536
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.732
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.732
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.732
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.732
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.733
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.733
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.733
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.733
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.734
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.734
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.734
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.734
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.734
//
//--------------------------------------------------------------------
//Bidding on DeliveryFirmStocks: Adobe 449.78551239056276
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.735
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.735
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.735
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.735
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.735
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.735
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.735
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.735
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.735
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.735
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.735
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.736
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.736
//
//Bidding on DeliveryFirmStocks: Adobe 502.63
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.736
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.736
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.736
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.737
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.737
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.737
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.737
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.737
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.737
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.737
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.737
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.738
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.738
//
//Bidding on DeliveryFirmStocks: Adobe 556.3657323348414
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.738
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.738
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.738
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.738
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.738
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.738
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.739
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.739
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.739
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.739
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.739
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.739
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.74
//
//Bidding on DeliveryFirmStocks: Adobe 590.5652308771263
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.74
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.74
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.74
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.74
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.74
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.74
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.74
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.74
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.741
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.741
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.741
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.741
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.741
//
//Bidding on DeliveryFirmStocks: Adobe 665.5859247670288
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.742
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.742
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.742
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.742
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.742
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.742
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.742
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.742
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.742
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.743
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.743
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.743
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.743
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.744
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.744
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.744
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.744
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.744
//
//Bidding on DeliveryFirmStocks: Adobe 723.6990644788154
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.744
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.744
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.744
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.744
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.744
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.744
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.744
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.745
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.745
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.745
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.745
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.745
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.745
//
//--------------------------------------------------------------------
//Bidding on DeliveryFirmStocks: Corel 497.00543155670556
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.745
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.745
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.745
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.745
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.745
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.746
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.746
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.747
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.747
//
//Bidding on DeliveryFirmStocks: Corel 506.5714877943185
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.747
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.747
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.747
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.748
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.748
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.748
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.748
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.748
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.749
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.749
//
//Bidding on DeliveryFirmStocks: Corel 531.5736378164561
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.749
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.749
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.749
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.749
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.749
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.75
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.75
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.751
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.751
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.751
//Corel:Selling at price:533.5 at timeStamp=2022-06-07 11:42:23.751
//
//Bidding on DeliveryFirmStocks: Corel 486.75522385935824
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.751
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.751
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.751
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.751
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.752
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.752
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.752
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.752
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.752
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.752
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.752
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.753
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.753
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.753
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.753
//Corel:Selling at price:533.5 at timeStamp=2022-06-07 11:42:23.753
//Corel:Selling at price:493.5 at timeStamp=2022-06-07 11:42:23.753
//
//Bidding on DeliveryFirmStocks: Corel 459.87535532603357
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.753
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.753
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.753
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.753
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.754
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.754
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.754
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.754
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.755
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.755
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.755
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.755
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.755
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.755
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.755
//Corel:Selling at price:533.5 at timeStamp=2022-06-07 11:42:23.755
//Corel:Selling at price:493.5 at timeStamp=2022-06-07 11:42:23.755
//Corel:Selling at price:469.5 at timeStamp=2022-06-07 11:42:23.755
//
//Bidding on DeliveryFirmStocks: Corel 405.57624668547527
//After trade on DeliveryFirmStocks of stock market
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.755
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.755
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.755
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.755
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.755
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.756
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.756
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.756
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.757
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.757
//Corel:Selling at price:533.5 at timeStamp=2022-06-07 11:42:23.757
//Corel:Selling at price:493.5 at timeStamp=2022-06-07 11:42:23.757
//Corel:Selling at price:469.5 at timeStamp=2022-06-07 11:42:23.757
//Corel:Selling at price:420.5 at timeStamp=2022-06-07 11:42:23.757
//
//--------------------------------------------------------------------
//End of day Display of stock market
//
//Stock Market Now...
//StockID: United Postal Service, price: 342.0, Metric: -28, description: UPS Common Stock
//StockID: Fedex, price: 156.5, Metric: 1, description: Fedex Common Stock
//StockID: DHL Group, price: 138.5, Metric: -31, description: DHL Common Stock
//StockID: AutoDesk, price: -13.0, Metric: -43, description: AutoDesk Common Share
//StockID: Adobe, price: 718.63, Metric: 40, description: Fedex Common Stock
//StockID: Corel, price: 349.5, Metric: 42, description: Corel Common Stock
//End of day trades executed
//
//Traded stocks Now...
//Fedex:Selling at price:178.5 at timeStamp=2022-06-07 11:42:23.758
//Fedex:Selling at price:168.5 at timeStamp=2022-06-07 11:42:23.758
//Fedex:Selling at price:172.5 at timeStamp=2022-06-07 11:42:23.758
//Fedex:Selling at price:153.5 at timeStamp=2022-06-07 11:42:23.758
//Fedex:Selling at price:139.5 at timeStamp=2022-06-07 11:42:23.758
//Fedex:Selling at price:147.5 at timeStamp=2022-06-07 11:42:23.758
//DHL Group:Buying at price:97.5 at timeStamp=2022-06-07 11:42:23.758
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.758
//DHL Group:Buying at price:96.5 at timeStamp=2022-06-07 11:42:23.758
//DHL Group:Buying at price:103.5 at timeStamp=2022-06-07 11:42:23.758
//DHL Group:Buying at price:88.5 at timeStamp=2022-06-07 11:42:23.759
//DHL Group:Buying at price:100.5 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:170.0 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:110.0 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:123.0 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:147.0 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:91.0 at timeStamp=2022-06-07 11:42:23.759
//AutoDesk:Selling at price:45.0 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:510.5 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:508.5 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:533.5 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:493.5 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:469.5 at timeStamp=2022-06-07 11:42:23.759
//Corel:Selling at price:420.5 at timeStamp=2022-06-07 11:42:23.759
