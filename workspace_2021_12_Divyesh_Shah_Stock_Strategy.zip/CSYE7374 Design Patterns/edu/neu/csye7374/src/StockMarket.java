/**
 * 
 */
package neu.csye7374.src;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author Divyesh
 *
 */
public class StockMarket {

	private static StockMarket instance;
	private List<StockAPI> stocks= new ArrayList<>();
	private List<StockAPI> tradedstocks=new ArrayList<>();
	
	
	private StockMarket() {
		super();
		instance=null;
	}
	
	public static StockMarket getInstance() {
		if (instance == null) {
			instance = new StockMarket();
		}
		return instance;
	}

	public List<StockAPI> getStocks() {
		return stocks;
	}

	public void setStocks(List<StockAPI> stocks) {
		this.stocks = stocks;
	}

	public List<StockAPI> getTradedstocks() {
		return tradedstocks;
	}

	public void setTradedstocks(List<StockAPI> tradedstocks) {
		this.tradedstocks = tradedstocks;
	}

   public void addStock(StockAPI s)
   {
	   getStocks().add(s);
   }
   public void removeStock(StockAPI s)
   {
	   getStocks().remove(s);
   }
   
   public void addTrade(StockAPI s)
   {
	   tradedstocks.add(s);
   } 
   
   public void showTrades()
   {
	   System.out.println("Traded stocks Now...");
	   for (StockAPI t : tradedstocks)
	    {System.out.println(t.getID()+":"+t.getTradeType()+" at price:"+t.getPrice()+" at timeStamp="+ new Timestamp(System.currentTimeMillis()));}
   } 
   
   public void showStocks()
   {
	   System.out.println("Stock Market Now...");
	   for (StockAPI s : getStocks())
	    {System.out.println(s.toString());}
   }
   
   public void trade(StockAPI s,String metricStrategyType)
   {
	   int metric=0;
	   
	   if(metricStrategyType=="BullMarketMetricStrategy")
		   metric=new BullMarketMetricStrategy().calculateMetric();
	   else if(metricStrategyType=="BearMarketMetricStrategy")
		   metric=new BearMarketMetricStrategy().calculateMetric();
	   else if(metricStrategyType=="BearMarketMetricStrategySingleton")
		   metric=BearMarketMetricStrategySingleton.getInstance().calculateMetric();
	   else
		   metric=BullMarketMetricStrategySingleton.getInstance().calculateMetric();
	   
	  
	  if (metric>0)
	  {
		  if (s.getBid() >= s.getPrice() )  // consider buying as stock shows positive performance 
		  {
			  StockAPI  tradebuystock = new StockAPI(s.getID(),s.getPrice(),s.getDescription(),s.getBid(),s.getTradeType());
			  tradebuystock.setTradeType("Buying");
			  addTrade(tradebuystock);
		  }
	  }
	  else // consider selling as stock shows negative performance 
	  {
		  StockAPI  tradesellstock = new StockAPI(s.getID(),s.getPrice(),s.getDescription(),s.getBid(),s.getTradeType());
		  tradesellstock.setTradeType("Selling");
		  addTrade(tradesellstock);
	  }	 
	  
	  s.setPrice(s.getPrice()+metric);
   }
   
   
   public static void demo() {
	 //creating market
	StockMarket SM = StockMarket.getInstance();
	System.out.println("Stocks: ");
	SM.showStocks();
	System.out.println("TradedStocks: ");
	SM.showTrades();
	
	//Creating Factory object to get Stocks Factory Objects
	AbstractFirmStockFactory abstractFirmStockFactory1=new DeliveryFirmStockFactory();
	AbstractFirmStockFactory abstractFirmStockFactory2=new SoftwareFirmStockFactory();
	
	//Getting Singleton Factory Stock Objects
	AbstractFirmStockFactory abstractFirmStockFactory3=DeliveryFimStockSingletonFactory.getInstance(); // Lazy Singleton Implementation of DeliveryFirmStockFactory
	AbstractFirmStockFactory abstractFirmStockFactory4=SoftwareFirmStockSingletonFactory.getInstance(); // Early Singleton Implementation of SoftwareFirmStockFactory
	
	
	
	//Creating Stock Objects using getObject Method
	StockAPI s1 =abstractFirmStockFactory1.getObject("United Postal Service",230.0,"UPS Common Stock",0.0,null);
	StockAPI s2= abstractFirmStockFactory1.getObject("Fedex",178.50,"Fedex Common Stock",0.0,null);
	StockAPI s3= abstractFirmStockFactory3.getObject("DHL Group", 97.50, "DHL Common Stock", 0.0, null);
	StockAPI s4 =abstractFirmStockFactory2.getObject("AutoDesk",170.0,"AutoDesk Common Share",0.0,null);
	StockAPI s5=abstractFirmStockFactory2.getObject("Adobe",444.63,"Fedex Common Stock",0.0,null);
	StockAPI s6=abstractFirmStockFactory4.getObject("Corel", 510.50, "Corel Common Stock", 0, null);
	
	
	SM.addStock(s1);
	SM.addStock(s2);
	SM.addStock(s3);
	SM.addStock(s4);
	SM.addStock(s5);
	SM.addStock(s6);
	
	
	//viewing stocks
	System.out.println("First display of stock market");
	SM.showStocks();
	System.out.println("--------------------------------------------------------------------");	
	
	// simulation of trading on s1
	for (int i=0; i<6; i++)
	{
		double start = s1.getPrice();
		double end = s1.getPrice()+ new BullMarketMetricStrategy().calculateMetric();   // Implementation of BullMarketMetricStrategy
		double random = new Random(System.currentTimeMillis()+1900).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on DeliveryFirmStocks: "+s1.getID()+" "+bid_now);
		s1.setBid(bid_now);
		System.out.println("After trade on DeliveryFirmStocks of stock market");
		SM.trade(s1,"BullMarketMetricStrategy");
		SM.showTrades();	
		System.out.println();
	}
	
	System.out.println("--------------------------------------------------------------------");
	
	// simulation of trading on s2
	for (int i=0; i<6; i++)
	{
		double start = s2.getPrice();
		double end = s2.getPrice()+ new BearMarketMetricStrategy().calculateMetric(); //// Implementation of BearMarketMetricStrategy
		double random = new Random(System.currentTimeMillis()+1700).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on SoftwareFirmStocks: "+s2.getID()+" "+bid_now);
		s2.setBid(bid_now);
		System.out.println("After trade on SoftwareFirmStocks of stock market");
		SM.trade(s2,"BearMarketMetricStrategy");
		SM.showTrades();
		System.out.println();
	}
	System.out.println("--------------------------------------------------------------------");
	
	// simulation of trading on s3
	for (int i=0; i<6; i++)
	{
		double start = s3.getPrice();
		double end = s3.getPrice()+ BullMarketMetricStrategySingleton.getInstance().calculateMetric(); // Implementation of BullMarketMetricStrategySingleton
		double random = new Random(System.currentTimeMillis()+1500).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on DeliveryFirmStocks: "+s3.getID()+" "+bid_now);
		s1.setBid(bid_now);
		System.out.println("After trade on DeliveryFirmStocks of stock market");
		SM.trade(s3,"BullMarketMetricStrategySingleton");
		SM.showTrades();	
		System.out.println();
	}
	System.out.println("--------------------------------------------------------------------");
	
	// simulation of trading on s4
	for (int i=0; i<6; i++)
	{
		double start = s4.getPrice();
		double end = s4.getPrice()+BullMarketMetricStrategySingleton.getInstance().calculateMetric(); // Implementation of BearketMetricStrategySingleton
		double random = new Random(System.currentTimeMillis()+1300).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on DeliveryFirmStocks: "+s4.getID()+" "+bid_now);
		s1.setBid(bid_now);
		System.out.println("After trade on DeliveryFirmStocks of stock market");
		SM.trade(s4,"BearMarketMetricStrategySingleton");
		SM.showTrades();	
		System.out.println();
	}
	System.out.println("--------------------------------------------------------------------");
	
	
	// simulation of trading on s5
	for (int i=0; i<6; i++)
	{
		double start = s5.getPrice();
		double end = s5.getPrice()+new BullMarketMetricStrategy().calculateMetric();   // Implementation of BullMarketMetricStrategy
		double random = new Random(System.currentTimeMillis()+1100).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on DeliveryFirmStocks: "+s5.getID()+" "+bid_now);
		s1.setBid(bid_now);
		System.out.println("After trade on DeliveryFirmStocks of stock market");
		SM.trade(s5,"BullMarketMetricStrategy");
		SM.showTrades();	
		System.out.println();
	}
	System.out.println("--------------------------------------------------------------------");
	
	// simulation of trading on s6
	for (int i=0; i<6; i++)
	{
		double start = s6.getPrice();
		double end = s6.getPrice()+new BearMarketMetricStrategy().calculateMetric(); //// Implementation of BearMarketMetricStrategy
		double random = new Random(System.currentTimeMillis()+900).nextDouble();
		double bid_now = start + (random * (end - start));
		System.out.println("Bidding on DeliveryFirmStocks: "+s6.getID()+" "+bid_now);
		s1.setBid(bid_now);
		System.out.println("After trade on DeliveryFirmStocks of stock market");
		SM.trade(s6,"BearMarketMetricStrategy");
		SM.showTrades();	
		System.out.println();
	}
	System.out.println("--------------------------------------------------------------------");
	
	System.out.println("End of day Display of stock market");
	System.out.println();
	SM.showStocks();
	System.out.println("End of day trades executed");
	System.out.println();
	SM.showTrades();
   }	   
}
	
