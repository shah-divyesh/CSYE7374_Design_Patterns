package neu.csye7374.src;

import java.util.concurrent.ThreadLocalRandom;

public class BearMarketMetricStrategySingleton implements MetricStrategyAPI {

	private static BearMarketMetricStrategySingleton instance;
	
	private BearMarketMetricStrategySingleton() {
		super();
		instance=null;
	}
	
	public static synchronized BearMarketMetricStrategySingleton getInstance() {
		if (instance == null) {
			instance = new BearMarketMetricStrategySingleton();
		}
		return instance;
	}


	@Override
	public int calculateMetric() {
		// TODO Auto-generated method stub
		int num = (int)((ThreadLocalRandom.current().nextInt( -40 + 1,0)*2.5)/2.99);
		return num;
	}
}
