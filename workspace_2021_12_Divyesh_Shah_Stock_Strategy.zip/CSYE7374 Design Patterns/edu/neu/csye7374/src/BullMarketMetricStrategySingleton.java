package neu.csye7374.src;

import java.util.concurrent.ThreadLocalRandom;

public class BullMarketMetricStrategySingleton implements MetricStrategyAPI{
	
	private static BullMarketMetricStrategySingleton instance;
	
	private BullMarketMetricStrategySingleton() {
		super();
		instance=null;
	}
	
	public static synchronized BullMarketMetricStrategySingleton getInstance() {
		if (instance == null) {
			instance = new BullMarketMetricStrategySingleton();
		}
		return instance;
	}


	@Override
	public int calculateMetric() {
		// TODO Auto-generated method stub
		int num = (int)((ThreadLocalRandom.current().nextInt(1, 40 + 1)*2.5)/2.99);
		return num;
	}

}
