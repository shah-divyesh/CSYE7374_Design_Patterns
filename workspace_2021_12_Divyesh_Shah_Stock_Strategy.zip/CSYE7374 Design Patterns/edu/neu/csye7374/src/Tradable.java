package neu.csye7374.src;

public interface Tradable {
	public void setBid(double Price);
	public  int getMetric();
}
