package neu.csye7374.src;

public class SoftwareFirmStockSingletonFactory extends AbstractFirmStockFactory {

private static SoftwareFirmStockSingletonFactory instance=new SoftwareFirmStockSingletonFactory();
	
	private SoftwareFirmStockSingletonFactory() {}
	
	public static SoftwareFirmStockSingletonFactory getInstance() {
		return instance;
	}
	
	@Override
	public StockAPI getObject(String ID, double price, String description, double bid, String tradeType) {
		// TODO Auto-generated method stub
		return new SoftwareFirmStocks(ID,price,description,bid,tradeType);
	}

}
