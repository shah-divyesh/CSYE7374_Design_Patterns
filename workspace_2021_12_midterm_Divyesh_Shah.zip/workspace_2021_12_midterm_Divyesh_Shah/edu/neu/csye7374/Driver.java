package neu.csye7374;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;



/**
 * 100 TOTAL POINTS Store Assignment:
 * 
 * NOTE: 40 Point deduction if submitted EITHER LATE OR INCORRECTLY: 
 * 		 file uploaded to Canvas must be zipped and correctly named eclipse workspace
 * 		 (e.g., workspace_2021_9_midterm_dan_peters.zip).
 *  
 * 
 * Complete the supplied class Driver code fragment to use and APPROPRIATELY demonstrate the following design patterns:
 * 
 * 	Builder, Decorator, Facade, Factory, Prototype, Singleton, State, Strategy
 * 
 *    	NOTE: 	APPROPRIATELY means within the context of the Store application design
 *    			arbitrary unrelated demonstrations of design patterns will receive partial.
 *    
 * Additionally, Completed Student submission of this application MUST meet the following requirements:
 * 
 * GIVEN:
 * - Driver class code fragment with supplied StoreAPI inner interface.
 * 
 * NOTE: all classes and interfaces MUST BE inner to Driver class.
 * 
 * 1. 10 POINTS: design SellableAPI inner interface;
 * 2. 25 POINTS: design Item inner class containing an ItemBuilder inner class: Item implements SellableAPI
 * 				NOTE: 
 * 				1. Item may be configured for EITHER in-store pickup, curb side service or delivery
 * 				2. All Item objects are to be instantiated by using a Singleton Factory and ItemBuilder.
 * 				3. Item objects must allow functionality to be added dynamically at run-time (e.g., purchase a Warrantee for Item) using Decorator pattern;
 * 				4. Design Service Item, an instrumented Multipurpose Item class allowing use of ANY of the Legacy Services Sold objects to be used by cloning and object composition (e.g., Services Sold in billed units) using Prototype pattern;
 *   
 * 3. 10 POINTS: design abstract Person inner class
 * 4. 15 POINTS: design Employee inner class containing an EmployeeBuilder inner class: Employee is derived from Person.
 * 				NOTE: 
 * 				1. Employee must indicate following:
 * 					a. is currently Employed or not
 * 					AND
 * 					b. is currently Student or not.
 * 				2. All Employee objects are to be instantiated by using a Singleton Factory and EmployeeBuilder.
 * 5. 20 POINTS: design Store inner class which implements StoreAPI to contain both Employees (MUST Use Person API) and Items (MUST Use Sellable API)
 * 				NOTE: 
 * 				1. Store must define and demonstrate operational behavioral by implementing State pattern as follows:
 * 					a. state Start (can only transition to state Stock)
 * 					b. state Stock (can only transition to state Open)
 * 					c. state Open (can only transition to state Closed)
 * 					d. state Closed (can transition to states Open, Start or Stock)
 * 				2. Store must define and demonstrate discount algorithms by implementing Strategy pattern.
 * 					a. Sale discount
 * 					b. Presidents Day discount
 * 					c. Memorial Day discount
 * 					e. Christmas discount
 * 					f. Clearance discount
 * 					g. Wholesaler's Only discount
 * 					h. Member's Only discount
 * 					i. Liquidation discount
 * 6. 20 POINTS: complete design of Driver class main method Sorting Employees and Items as specified.
 * 
 * @author dpeters
 *
 * Revision History:
 * 
 * 
 * 1.0 Implemented Person, Employee, Item, Store and associated interfaces.
 * 1.5 Implemented Builder pattern and Singleton Factories for Item and Employee. 
 * 
 * 2.0 Implemented Decorator pattern for dynamically adding functionality to Item objects 
 * 2.5 Implemented State pattern for managing Store behavior in defined states 
 * 
 * 3.0 Implemented Prototype pattern for dynamically handling Legacy Service Sold objects
 * 
 * 4.0 Implemented Strategy pattern for discount algorithms
 * 4.1 Implemented Commented and STD output Revision History.
 * 4.2 Implemented Commented and STD output Revision History.
 * 
 */
public class Driver {
	Scanner scanner =new Scanner(System.in);
	public static final int MAJOR_REVISION;
	public static final int MINOR_REVISION;
	private static String version; 
	private Store store = new Store("Wollaston's");
	
	Driver(){}

	static {
		MAJOR_REVISION = 1;
		MINOR_REVISION = 0;
		version = Integer.valueOf(MAJOR_REVISION)
				+ "."
				+ Integer.valueOf(MINOR_REVISION);
		
	}
	
	public Store getStore() {
		return store;
	}
	public void setStore(Store store) {
		this.store = store;
	}
	
	
	/**
	 * Student TODO
	 */ 
	
	/**
	 * Student TODO
	 * Decorator pattern
	 * TODO Student complete implementation
	 */
	public interface WarranteeDecorator{
		public  Item warranteePlan();
	}
	
	public static class BasicWarranteePlan implements WarranteeDecorator{

		protected Item item;
		
		public BasicWarranteePlan(SellableAPI item) {
			super();
			this.item = (Item) item;
		}

		@Override
		public Item warranteePlan() {
			// TODO Auto-generated method stub
			item.setWarranteeChoice("Basic Warrantee Plan");
			item.setItemDescription(item.getItemDescription() +" Warrantee Plan worth $149.99: Cover basic service like minor repair and cleaning.");
			item.itemPrice+=item.itemPrice + 149.99;
			return item;
		}
		
	}
	
	public class AdvanceWarranteePlan implements WarranteeDecorator{

		protected Item item;
		
		public AdvanceWarranteePlan(SellableAPI item) {
			super();
			this.item = (Item)item;
		}
		
		@Override
		public Item warranteePlan() {
			// TODO Auto-generated method stub
			item.setWarranteeChoice("Advance Warrantee Plan");
			item.setItemDescription(item.getItemDescription() +" Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage");
			item.itemPrice+=item.itemPrice + 349.99;
			return item;
		}
		
	}
	
	
	/**
	 * Interface SellableAPI
	 * TODO Student complete implementation
	 *  
	 * @author dpeters
	 *
	 */
	public interface SellableAPI {
		void setDeliveryType(String deliveryType);
		void setWarranteeType(String warranteeType);
	}
	
	/**
	 * Student TODO
	 * Facade pattern
	 */
	
	/**
	 * Student TODO
	 * Factory pattern
	 */
	
	public static  abstract class AbstractEmployeeFactory {
		public AbstractEmployeeFactory() {}
		public abstract Employee getEmployeeObject(int id,int age,String firstName, String lastName,double wage,boolean isEmployed,boolean isStudent);		
	}
	
	public static  abstract class AbstractItemFactory {
		public AbstractItemFactory() {}
		public abstract Item getItemObject(int itemID, double itemPrice, String itemName, String itemDescription, String deliveryChoice, String warranteeChoice);
	}
	
	
	/**
	 * Student TODO
	 * Prototype pattern
	 */
	public static abstract class Service implements Cloneable{
		private int serviceId;
		private double servicePrice;
		protected String serviceType;
		protected LocalDate date;
		
		abstract String serviceDescription();
		
		public Service() {
			super();
			// TODO Auto-generated constructor stub
		}

		public  Service(int serviceId, double servicePrice, String serviceType, LocalDate date) {
			super();
			this.serviceId = serviceId;
			this.servicePrice = servicePrice;
			this.serviceType = serviceType;
			this.date = date;
		}

		public double getServicePrice() {
			return servicePrice;
		}

		public void setServicePrice(double servicePrice) {
			this.servicePrice = servicePrice;
		}

		public LocalDate getDate() {
			return date;
		}

		public void setDate(LocalDate date) {
			this.date = date;
		}

		public int getServiceId() {
			return serviceId;
		}
		
		public void setServiceId(int serviceId) {
			this.serviceId = serviceId;
		}
		
		public String getServiceType() {
			return serviceType;
		}
		
		public void setServiceType(String serviceType) {
			this.serviceType = serviceType;
		}
		
		@Override
	   public Object clone() {
	      Object clone = null;
	      
	      try {
	         clone = super.clone();
	         
	      } catch (CloneNotSupportedException e) {
	         e.printStackTrace();
	      }
	      
	      return clone;
		}
			
	}

	static class MaintenanceService extends Service{

		public MaintenanceService(int serviceId, double servicePrice, String serviceType, LocalDate date){
			super(serviceId,servicePrice,serviceType,date);
		}
		
		@Override
		String serviceDescription() {
			// TODO Auto-generated method stub
			return ",  Maintenance Service is Requested on : "+ LocalDate.now();
		}
		
	}
	
	static class  RepairService extends Service{

		public RepairService(int serviceId, double servicePrice, String serviceType, LocalDate date){
			super(serviceId,servicePrice,serviceType,date);
		}
		
		@Override
		String serviceDescription() {
			// TODO Auto-generated method stub
			return ",  Repair Service is Requested on: "+ LocalDate.now();
			
		}
		
	}
	
	public static class ServiceCache{
		private static Map<Integer, Service> serviceMap  = new HashMap<Integer, Service>();
		
		
		public static Service getService(int serviceId) {
			Service cachedService = serviceMap.get(serviceId);
		      return (Service) cachedService.clone();
		   }

		   // for each shape run database query and create shape
		   // shapeMap.put(shapeKey, shape);
		   // for example, we are adding three shapes
		   
		   public static void loadCache() {
			   Driver.Service maintaenanceService = new MaintenanceService(1,99.99,"maintaenance",LocalDate.now());
			   maintaenanceService.setServiceId(1);
			   serviceMap.put(maintaenanceService.getServiceId(),maintaenanceService);

			   Service repairService = new RepairService(2,199.99,"repair",LocalDate.now());
			   repairService.setServiceId(2);
		      serviceMap.put(repairService.getServiceId(),repairService);

		   }
	}
	
	
	/**
	 * Student TODO
	 * 
	 * Legacy class
	 * TODO Student complete implementation
	 */
	
	/**
	 * Student TODO
	 * Singleton pattern
	 */
	
	public static class EmployeeFactory extends AbstractEmployeeFactory{
		private static EmployeeFactory instance;  // Lazy Singleton Factory Class
		
		private  EmployeeFactory() {
			super();
			instance=null;
		}
		
		public static synchronized EmployeeFactory getInstance() {
			if (instance == null) {
				instance = new EmployeeFactory();
			}
			return instance;
		}
		
		@Override
		public Employee getEmployeeObject(int id,int age,String firstName, String lastName,double wage,boolean isEmployed,boolean isStudent) {
			// TODO Auto-generated method stub
			return new Employee(id,age,firstName,lastName,wage,isEmployed,isStudent);
		}
	}
	
	
	public static class ItemFactory extends AbstractItemFactory{

		private static ItemFactory instance=new ItemFactory(); // Eager Singleton Factory Class
			
		private  ItemFactory() {
			super();
		}
		
		public synchronized ItemFactory getInstance() {
			return instance;
		}
		
		@Override
		public Item getItemObject(int itemID, double itemPrice, String itemName, String itemDescription,String deliveryChoice, String warranteeChoice) {
			// TODO Auto-generated method stub
			return new Item(itemID, itemPrice, itemName, itemDescription, deliveryChoice, warranteeChoice);
		}
		
	}
	
	
	/**
	 * Student TODO
	 * State pattern
	 */
	public interface State{
		public void storeState(StoreContext storeContext);
	}
	
	public static class StartState implements State{
		
		private static StartState startState;
		
		private  StartState() {
			super();
			startState=null;
		}
		
		public static synchronized StartState getInstance() {
			if (startState == null) {
				startState = new StartState();
			}
			return startState;
		}
		@Override
		public void storeState(StoreContext context) {
			// TODO Auto-generated method stub
			System.out.println("Store is in Start State");
			context.setCurrentState(StockState.getInstance());
		}
		
	}
	
	public static class StockState implements State{
		
		private static StockState stockState;
		
		private  StockState() {
			super();
			stockState=null;
		}
		
		public static synchronized StockState getInstance() {
			if (stockState == null) {
				stockState = new StockState();
			}
			return stockState;
		}
		@Override
		public void storeState(StoreContext context) {
			// TODO Auto-generated method stub
			System.out.println("Store is in Stock State ");
			context.setCurrentState(OpenState.getInstance());
		}
		
	}
	
	public static class OpenState implements State{
		
		private static OpenState openState;
		
		private  OpenState() {
			super();
			openState=null;
		}
		
		public static synchronized OpenState getInstance() {
			if (openState == null) {
				openState = new OpenState();
			}
			return openState;
		}
		@Override
		public void storeState(StoreContext context) {
			// TODO Auto-generated method stub
			System.out.println("Store is in Open State ");
			context.setCurrentState(CloseState.getInstance());
		}	
	}
	
	public static class CloseState implements State{
		
		private static CloseState closeState;
		
		private  CloseState() {
			super();
			closeState=null;
		}
		
		public static synchronized CloseState getInstance() {
			if (closeState == null) {
				closeState = new CloseState();
			}
			return closeState;
		}
		@Override
		public void storeState(StoreContext context) {
			// TODO Auto-generated method stub
			System.out.println("Store is in Close State ");
			int x=ThreadLocalRandom.current().nextInt(0,3);
			switch(x) {
				case 0:
					context.setCurrentState(StartState.getInstance());
					break;
				case 1:
					context.setCurrentState(StockState.getInstance());
					break;
				case 2:
					context.setCurrentState(OpenState.getInstance());
					break;
			}
			
		}	
	}
	
	public class StoreContext{
		private State currentState;
		
		public StoreContext(State storeState) {
			super();
			this.currentState = storeState;
			
			if(currentState==null) {
				this.currentState=StartState.getInstance();
			}
		}

	    public State getCurrentState() {
	        return currentState;
	    }
	 
	    public void setCurrentState(State currentState) {
	        this.currentState = currentState;
	    }
	     
	    public void update() {
	        currentState.storeState(this);
	    }
	}


	/**
	 * Student TODO
	 * Strategy pattern
	 * TODO Student complete implementation
	 */
	public interface DiscountStrategy{
		public String discount(Item item);
	}
	
	public static class SaleDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.15 ;
			return "Received Discount of 15% on "+ item.getItemName()+" on Sale's Day. Final price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class PresidentDayDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.10 ;
			return "Received Discount of 10% on "+ item.getItemName()+" on President's Day. Final price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class MemorialDayDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.20 ;
			return "Received Discount of 20% on "+ item.getItemName()+" on Memorial Day. Final price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class ChristmasDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.25 ;
			return "Received Discount of 25% on "+ item.getItemName()+" on Christmas. Final Price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class ClearanceDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.05 ;
			return "Received Discount of 5% on "+ item.getItemName()+" in Clearance Sale. Final Price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class WholeSalersOnlyDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.40 ;
			return "Received Discount of 40% on "+ item.getItemName()+" as Wholesaler's discount. Final Price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class MembersOnlyDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.12 ;
			return "Received Discount of 12% on "+ item.getItemName()+" as Member's Discount. Final Price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class LiquidationDiscount implements DiscountStrategy{

		@Override
		public String discount(Item item) {
			// TODO Auto-generated method stub
			double discountedPrice= item.getItemPrice() - item.getItemPrice()* 0.3 ;
			return "Received Discount of 30% on "+ item.getItemName()+" as Liquidation Discount. Final Price = "+ Math.round(discountedPrice*100.0)/100.0;
		}
	}
	
	public class StoreDiscountStrategy{
		private DiscountStrategy discountStrategy;

		public StoreDiscountStrategy(DiscountStrategy discountStrategy) {
			super();
			this.discountStrategy = discountStrategy;
		}
		
		public String discountedPrice(Item item) {
			return discountStrategy.discount(item);
		}
	}
	
	/**
	 * Student TODO
	 * abstract Person class
	 * TODO Student complete implementation
	 */
	// DONE
	static abstract class Person {
		private int id;
		private String firstName;
		private String lastName;
		private int age;
		
		public Person(int id,int age,String firstName, String lastName) {
			super();
			this.id=id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
		}
		
		public Person() {}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		
		@Override
		public String toString() {
			return "Person [id= "+ id+", firstName= " + firstName + ", lastName= " + lastName + ", age= " + age + "]";
		}	
	}
	
	/**
	 * Person abstract class
	 * TODO Student complete implementation
	 * 
	 * @author dpeters
	 *
	 */
	
	
	// DONE
	/**
	 * Student TODO
	 * Employee class
	 * TODO Student complete implementation
	 * 
	 * @author dpeters
	 *
	 */	 
	static class Employee extends Person{
		
		private double wage;
		private boolean isEmployed;
		private boolean isStudent;

		public Employee() {
			super();
		}
		
		public double getWage() {
			return wage;
		}

		public void setWage(double wage) {
			this.wage = wage;
		}

		public boolean isEmployed() {
			return isEmployed;
		}

		public void setEmployed(boolean isEmployed) {
			this.isEmployed = isEmployed;
		}

		public boolean isStudent() {
			return isStudent;
		}

		public void setStudent(boolean isStudent) {
			this.isStudent = isStudent;
		}

		public Employee(int id,int age,String firstName, String lastName, double wage,boolean isEmployed,boolean isStudent) {
			super(id,age,firstName, lastName);
			this.wage=wage;
			this.isEmployed=isEmployed;
			this.isStudent=isStudent;
		}

		@Override
		public String toString() {
			return "\nEmployee ["+ super.toString() +", wage= "+ wage +", isEmployed=" + isEmployed + ", isStudent=" + isStudent +  "]";
		}
		
		
		class EmployeeBuilder{	
			public EmployeeBuilder() {
				super();
				// TODO Auto-generated constructor stub
			}

			public Employee getEmployee(String s) {
				AbstractEmployeeFactory employeeFactory=new EmployeeFactory().getInstance();
				String[] tokens=s.split(",");
				Employee employee=employeeFactory.getEmployeeObject(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]), tokens[2], tokens[3],Double.parseDouble(tokens[4]),true,Integer.parseInt(tokens[1])>29 ? false:true);
				return employee;
			}
		}
		
		
		
	}
	

	/**
	 * Student TODO
	 * Item class
	 * TODO Student complete implementation
	 * 
	 * @author dpeters
	 *
	 */
	
	public static class Item implements SellableAPI{
		
		private int itemID;
		private double itemPrice;
		private String itemName;
		private String itemDescription;
		private String deliveryChoice;
		private String warranteeChoice;
		
		public Item() {
			super();
		}

		public Item(int itemID, double itemPrice, String itemName, String itemDescription, String deliveryChoice, String warranteeChoice) {
			super();
			this.itemID = itemID;
			this.itemPrice = itemPrice;
			this.itemName = itemName;
			this.itemDescription = itemDescription;
			this.deliveryChoice = deliveryChoice;
			this.warranteeChoice = warranteeChoice;
		}

		public int getItemID() {
			return itemID;
		}

		public void setItemID(int itemID) {
			this.itemID = itemID;
		}

		public double getItemPrice() {
			return itemPrice;
		}

		public void setItemPrice(double itemPrice) {
			this.itemPrice = itemPrice;
		}

		public String getItemName() {
			return itemName;
		}

		public void setItemName(String itemName) {
			this.itemName = itemName;
		}

		public String getItemDescription() {
			return itemDescription;
		}

		public void setItemDescription(String itemDescription) {
			this.itemDescription = itemDescription;
		}

		public String getDeliveryChoice() {
			return deliveryChoice;
		}

		public void setDeliveryChoice(String deliveryChoice) {
			this.deliveryChoice = deliveryChoice;
		}

		public String getWarranteeChoice() {
			return warranteeChoice;
		}

		public void setWarranteeChoice(String warranteeChoice) {
			this.warranteeChoice = warranteeChoice;
		}

		@Override
		public void setDeliveryType(String deliveryType) {
			// TODO Auto-generated method stub
			this.deliveryChoice=deliveryType;
		}

		@Override
		public void setWarranteeType(String warranteeType) {
			// TODO Auto-generated method stub
			this.warranteeChoice=warranteeType;
		}
		
		
		 class ItemBuilder{
			public ItemBuilder() {
				super();
			}
			
			public Item getPickUpItemObject(String s) {
				AbstractItemFactory itemFactory=new ItemFactory().getInstance();
				String[] tokens=s.split(",");
				Item item=itemFactory.getItemObject(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1]), tokens[2], tokens[3],"In-Store Pickup", warranteeChoice==null?"No warrantee Plan":warranteeChoice);
				return item;
			}
			
			public Item getCurbSideItemObject(String s) {
				AbstractItemFactory itemFactory=new ItemFactory().getInstance();
				String[] tokens=s.split(",");
				Item item=itemFactory.getItemObject(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1]), tokens[2], tokens[3],"Curb Side Service", warranteeChoice==null?"No warrantee Plan":warranteeChoice);
				return item;
			}
			
			public Item getDeliveryItemObject(String s) {
				AbstractItemFactory itemFactory=new ItemFactory().getInstance();
				String[] tokens=s.split(",");
				Item item=itemFactory.getItemObject(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1]), tokens[2], tokens[3],"Delivery", warranteeChoice==null?"No warrantee Plan":warranteeChoice);
				return item;
			}
		}


		@Override
		public String toString() {
			return "\nItem [itemID=" + itemID + ", itemPrice=" + (double)Math.round(itemPrice*100.0)/100.0 + ", itemName=" + itemName
					+ ", itemDescription=" + itemDescription + ", deliveryChoice=" + deliveryChoice
					+ ", warranteeChoice=" + warranteeChoice + "]";
		}
		 
		
		
	}
	
	/**
	 * StoreAPI interface
	 * TODO Student complete implementation
	 */
	private interface StoreAPI {
		void add(Person person);
		void add(SellableAPI item);
		void sortEmployees(Comparator<Person> c);
		void sortItems(Comparator<SellableAPI> c);
	}
	/**
	 * Student TODO
	 * Store class
	 * TODO BY STUDENT Complete implementation
	 * 
	 * @author dpeters
	 *
	 */
	private class Store implements StoreAPI {
		private String name =null;
		private List<SellableAPI> itemList = new ArrayList<>();
		private List<Person> personList = new ArrayList<>();

		// Student TODO

		public Store() {
			super();
		}
		
		public Store(String name) {
			super();
			this.name = name;
		}
		
		@Override
		public void add(Person person) {
			// TODO Auto-generated method stub
			personList.add(person);
		}
		
		
		@Override
		public void add(SellableAPI item) {
			// TODO Auto-generated method stub
			ServiceCache.loadCache();
			Item item1=(Item) item;
			
			
			System.out.print("Do you want to buy warrantee plan along with "+ item1.itemName+"? Press  0. No Warrantee Plan\t 1. Basic Warrantee Plan\t 2. Advance Warrantee Plan \n ");
			int choice=scanner.nextInt();
			switch(choice) {
				case 1:
					BasicWarranteePlan basicWarranteePlan = new BasicWarranteePlan(item1);
					item1=basicWarranteePlan.warranteePlan();
					break;
				case 2:
					AdvanceWarranteePlan advanceWarranteePlan = new AdvanceWarranteePlan(item1);
					item1=advanceWarranteePlan.warranteePlan();
					break;
			}
			
			System.out.print("Do you want to buy services along with "+ item1.itemName+"? Press  0. No Service\t 1. Maintenance Service \t 2. Repair Service \n ");
			choice=scanner.nextInt();
			switch(choice) {
				case 1:
					Service clonedMaintenanceService= (Service)ServiceCache.getService(1);
					item1.setItemPrice(item1.getItemPrice()+clonedMaintenanceService.getServicePrice());
					item1.setItemDescription(item1.getItemDescription()+clonedMaintenanceService.serviceDescription());
					break;
				case 2:
					Service clonedRepairService= (Service)ServiceCache.getService(2);
					item1.setItemPrice(item1.getItemPrice()+clonedRepairService.getServicePrice());
					item1.setItemDescription(item1.getItemDescription()+clonedRepairService.serviceDescription());
					break;
			}
			
			
			itemList.add(item1);
			
			
		}
		
		@Override
		public void sortEmployees(Comparator<Person> c) {
			// TODO Auto-generated method stub
			c = (o1, o2) -> Integer.valueOf(o1.getId()).compareTo(Integer.valueOf(o2.getId()));
			personList.sort(c);
			for (Person s : personList) {
	            System.out.println(s.toString());
	        }
		}
		
		@Override
		public void sortItems(Comparator<SellableAPI> c) {
			// TODO Auto-generated method stub
			Collections.sort(itemList, new Comparator<SellableAPI>() {
	            @Override
	            public int compare(SellableAPI o1, SellableAPI o2) {
	                Item i1 = Item.class.cast(o1);
	                Item i2 = Item.class.cast(o2);
	                return Integer.valueOf(i1.getItemID()).compareTo(Integer.valueOf(i2.getItemID()));
	            }
			});
			
			for (SellableAPI s : itemList) {
	            System.out.println(s.toString());
	        }
		}
		
		
		@Override
		public String toString() {
			return "Store [name=" + name + ", \nitemList=" + itemList.toString()+ ", \n personList=" + personList.toString() + "]";
		}
		
		/**
		 * TODO BY STUDENT
		 * 
		 * Implement StoreAPI, etc.
		 */
		
		
		
	} // end Store class
	
	/**
	 * return String representation of Driver state.
	 * (Employees and Items)
	 */
//	@Override
	public String toString() {
		// TODO BY STUDENT
		return store.toString();
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	// DONE
	public void addEmployeesToStore() {
		System.out.println("\n\t" + Driver.class.getName() + ".addEmployeesToStore()...");
		
		/**
		 * add employees to store USING Factory Singleton
		 * 5 POINTS: 
		 * (by parsing the following CSV Strings)
		 * 
		 * "3,21,James,Pope,12.99"
		 * "1,31,Bob,James,15.99"
		 * "2,27,Don,Hope,14.99"
		 */

		// TODO BY STUDENT
		Driver.Employee employee=new Employee();
		Employee.EmployeeBuilder employeeBuilder=employee.new EmployeeBuilder();
		store.add(employeeBuilder.getEmployee("3,21,James,Pope,12.99"));
		store.add(employeeBuilder.getEmployee("1,31,Bob,James,15.99"));
		store.add(employeeBuilder.getEmployee("2,27,Don,Hope,14.99"));
		
		System.out.println("\n\t" + Driver.class.getName() + ".addEmployeesToStore()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void addItemsToStore() {
		System.out.println("\n\t" + Driver.class.getName() + ".addItemsToStore()...");
		
		/**
		 * add items to store inventory USING Factory Singleton
		 * 5 POINTS: 
		 * (by parsing the following CSV Strings
		 * 
		 * "3,1.49,Wheat Bread,Healthy 30 Calorie Wheat Bread"
		 * "1,3.49,OJ,Florida Orange Juice with Calcium"
		 * "4,1249.99,Microsoft Surface,Microsoft Surface Tablet"
		 * "2,2.49,Skim Milk,Vitamin D Fortified Skim Milk"
		 */
		
		// TODO BY STUDENT 	
		Item item=new Item();
		Item.ItemBuilder itemBuilder=item.new ItemBuilder();
		store.add(itemBuilder.getDeliveryItemObject("3,1.49,Wheat Bread,Healthy 30 Calorie Wheat Bread"));
		store.add(itemBuilder.getDeliveryItemObject("1,3.49,OJ,Florida Orange Juice with Calcium"));
		store.add(itemBuilder.getPickUpItemObject("4,1249.99,Microsoft Surface,Microsoft Surface Tablet"));
		store.add(itemBuilder.getCurbSideItemObject("2,2.49,Skim Milk,Vitamin D Fortified Skim Milk"));
	
		System.out.println("\n\t" + Driver.class.getName() + ".addItemsToStore()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void showStoreOperationalStates() {
		System.out.println("\n\t" + Driver.class.getName() + ".showStoreOperationalStates()...");
		
		// TODO BY STUDENT 	
		
		StoreContext storeContext=new StoreContext(null);
		storeContext.update();
		storeContext.update();
		storeContext.update();
		storeContext.update();
		storeContext.update();
		System.out.println("\n\t" + Driver.class.getName() + ".showStoreOperationalStates()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesID() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesID()...");
		
		System.out.println("Sort employees by PERSON ID...");
		 // TODO BY STUDENT
		
		Comparator<Person> sortById = (o1, o2) -> Double.valueOf(o1.getId()).compareTo(Double.valueOf(o2.getId()));
        store.personList.sort(sortById);
        
		System.out.println("Sort items by ITEM ID...");
		 // TODO BY STUDENT
		Collections.sort(store.itemList, new Comparator<SellableAPI>() {
            @Override
            public int compare(SellableAPI o1, SellableAPI o2) {
                Item i1 = Item.class.cast(o1);
                Item i2 = Item.class.cast(o2);

                return Integer.valueOf(i1.getItemID()).compareTo(Integer.valueOf(i2.getItemID()));
            }
        });
		
		System.out.println(getStore());

		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesID()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesLastName() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesLastName()...");
		
		System.out.println("Sort employees by PERSON LAST NAME...");
		 // TODO BY STUDENT
		Comparator<Person> sortByLastName = (o1, o2) -> String.valueOf(o1.getLastName()).compareToIgnoreCase(String.valueOf(o2.getLastName()));
        store.personList.sort(sortByLastName);
        
		System.out.println("Sort items by ITEM NAME...");
		 // TODO BY STUDENT
		Collections.sort(store.itemList, new Comparator<SellableAPI>() {
            @Override
            public int compare(SellableAPI o1, SellableAPI o2) {
                Item i1 = Item.class.cast(o1);
                Item i2 = Item.class.cast(o2);

                return i1.getItemName().compareToIgnoreCase(i2.getItemName());
            }
        });
		
		System.out.println(getStore());
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesLastName()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesFirstName() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesFirstName()...");
		
		System.out.println("Sort employees by PERSON FIRST NAME...");
		 // TODO BY STUDENT
		Comparator<Person> sortByFirstName = (o1, o2) -> String.valueOf(o1.getFirstName()).compareToIgnoreCase(String.valueOf(o2.getFirstName()));
        store.personList.sort(sortByFirstName);
        
		System.out.println("Sort items by ITEM PRICE...");
		 // TODO BY STUDENT
		
		Collections.sort(store.itemList, new Comparator<SellableAPI>() {
            @Override
            public int compare(SellableAPI o1, SellableAPI o2) {
                Item i1 = Item.class.cast(o1);
                Item i2 = Item.class.cast(o2);

                return Double.valueOf(i1.getItemPrice()).compareTo(Double.valueOf(i2.getItemPrice()));
            }
        });

		System.out.println(getStore());

		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesFirstName()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void showStoreDiscountAlgorithms() {
		System.out.println("\n\t" + Driver.class.getName() + ".showStoreDiscountAlgorithms()...");
		
		 // TODO BY STUDENT execute all discount algorithms
		Item item1=new Item();
		Item.ItemBuilder itemBuilder=item1.new ItemBuilder();
		Item item=itemBuilder.getDeliveryItemObject("5,899.99,Iphone 11,Apple smart phone");
		
		System.out.println("The price of Iphone 11 originally is :"+ item.itemPrice);
		System.out.println("Price of Same Iphone 11 on following days is :- ");
		System.out.println(new StoreDiscountStrategy(new SaleDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new PresidentDayDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new ChristmasDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new ClearanceDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new WholeSalersOnlyDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new MembersOnlyDiscount()).discountedPrice(item));
		System.out.println(new StoreDiscountStrategy(new LiquidationDiscount()).discountedPrice(item));
		
		System.out.println("\n\t" + Driver.class.getName() + ".showStoreDiscountAlgorithms()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesAgeYoungest() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesAgeYoungest()...");
		
		System.out.println("Sort employees by PERSON AGE (YOUNGEST FIRST)...");
		 // TODO BY STUDENT
		Comparator<Person> sortByAge = (o1, o2) -> Integer.valueOf(o1.getAge()).compareTo(Integer.valueOf(o2.getAge()));
        store.personList.sort(sortByAge);
		
		System.out.println("Sort items by ITEM Description...");
		 // TODO BY STUDENT
		
		Collections.sort(store.itemList, new Comparator<SellableAPI>() {
            @Override
            public int compare(SellableAPI o1, SellableAPI o2) {
                Item i1 = Item.class.cast(o1);
                Item i2 = Item.class.cast(o2);

                return i1.getItemDescription().compareToIgnoreCase(i2.getItemDescription());
            }
        });
		System.out.println(getStore());

		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesAgeYoungest()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesAgeOldest() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesAgeOldest()...");
		
		System.out.println("Sort employees by PERSON AGE (OLDEST FIRST)...");
		 // TODO BY STUDENT
		Comparator<Person> sortByAge = (o1, o2) -> Integer.valueOf(o1.getAge()).compareTo(Integer.valueOf(o2.getAge()));
		store.personList.sort(sortByAge);
        Collections.reverse(store.personList);
		System.out.println(getStore());

		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesAgeOldest()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public void sortEmployeesHighestWage() {
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesHighestWage()...");
		
		System.out.println("Sort employees by HIGHEST WAGE...");
		 // TODO BY STUDENT 10 POINTS: 
		Collections.sort(store.personList, new Comparator<Person>() {
            @Override
            public int compare(Person o1, Person o2) {
            	Employee e1=Employee.class.cast(o1);
            	Employee e2=Employee.class.cast(o2);
                return Double.valueOf(e1.getWage()).compareTo(Double.valueOf(e2.getWage()));
            }
        });
		
		Collections.reverse(store.personList);
		
		System.out.println(getStore());
		
		System.out.println("\n\t" + Driver.class.getName() + ".sortEmployeesHighestWage()... done!");
	}
	
	/**
	 * TODO BY STUDENT
	 * 
	 * Complete the remainder of the design for this method code fragment
	 */
	public static void main(String[] args) {
		System.out.println("CSYE7374 Midterm July 2022 ...");
		
		Driver obj = new Driver();
		obj.setStore(obj.store);
		System.out.println(obj);
		
		  // TODO BY STUDENT
		
		/**
		 *	TODO BY STUDENT
		 * 
		 * Demonstrate Store operational behavior
		 * in defined states TODO as defined by State pattern
		 */
		 obj.showStoreOperationalStates();
		 
		 /**
		  *	TODO BY STUDENT
		  * 
		  * Demonstrate Store discount algorithms
		  * TODO as defined by Strategy pattern
		  */
		 obj.showStoreDiscountAlgorithms();
		 
		 /**
		  *	TODO BY STUDENT
		  * 
		  * Add Employees and Items to Store
		  */
		 
		 obj.addEmployeesToStore();
		 obj.addItemsToStore();
		
		/**
		 *	TODO BY STUDENT
		 *
		 * show original store object state (Employees and Items)
		 */
		 // TODO BY STUDENT
		obj.toString();
		/**
		 *	TODO BY STUDENT
		 *
		 * Sorting to be completed by Student as indicated (TODO) 5 POINTS: 
		 */
		obj.sortEmployeesID();
		
		obj.sortEmployeesLastName();
		
		obj.sortEmployeesFirstName();
		
		obj.sortEmployeesAgeYoungest();
		
		obj.sortEmployeesAgeOldest();
//		
		/**
		 *	TODO BY STUDENT
		 *
		 * Sort employees by HIGHEST WAGE 5 POINTS: 
		 */
		obj.sortEmployeesHighestWage();
		
		/**
		 *	TODO BY STUDENT
		 *
		 * Revision History to STD output (console)
		 */
		Driver.showRevisionHistory();
				
		System.out.println("CSYE7374 Midterm July 2022 ... done!");
	}
	/*
	 *	TODO BY STUDENT
	 *
	 * showRevisionHistory on STD output (console) 
	 * 
	 * 1.0 Implemented skeleton classes for blah, blah, ... 
	 * 1.1 Completed Implementation for class blah, blah, ...  
	 * 1.2 Fixed bug blah, blah, ... bychanging blah, blah... 
	 * 1.3 Completed Implementation for class blah, blah, ...
	 * 
	 * 2.0 Started implementation design pattern blah, ... 
	 * 2.1 Fixed bug blah, blah, ... by changing blah, blah... 
	 * 2.2 Fixed bug blah, blah, ... by changing blah, blah... 
	 * 2.3 Completed Implementation for design pattern blah, ...
	 * 
	 * 3.0 Implemented Commented and STD output Revision History.
	 * 
	 */
	public static void showRevisionHistory() {
		System.out.println();
		System.out.println(Driver.class.getName() + ".showRevisionHistory()...");
		System.out.println();
		System.out.println("1.0 Implemented skeleton classes for Person, Employee");
		System.out.println("1.1 Created Sellable interface and StoreAPI interface");
		System.out.println("1.2 Implemented skeleton classes for Item implementing SellableAPI and Store implementing StoreAPI");
		System.out.println("1.3 Created AbstractFactory interface for Employee and Item Singleton Factory and implemented ItemBuilder and EmployeeBuilder");
		System.out.println("1.4 Fixed bug in getEmployee() in EmployeeBuilder and similar methods in ItemBuilder by changing the references employee and Item objects ");
		System.out.println("1.5 Completed the code to add Employees and Items in Store");
		System.out.println("1.6 Completed the code of various sort methods for Employees and Items");
		System.out.println("1.7 Fixed the bug in the code of various sort methods for Items as its List was of type SellableAPI");
		
		System.out.println("2.0 Started implementation of State, Strategy, Decorator, Prototype");
		System.out.println("2.1 Fixed bug in Decorator Pattern to pass item Object with decoration");
		System.out.println("2.2 Fixed bug in discount method of Strategy pattern to show the implementation of Strategy pattern ");
		System.out.println("2.3 Completed Implementation for design pattern State,Decorator, Strategy ...");
		System.out.println("2.4 Started Implementation for design pattern Prototype");
		System.out.println("2.5 Fixed bug in the ServiceCache Conrete class");
		System.out.println("2.6 Completed Implementation for design pattern Prototype");
		
		System.out.println("3.0 Implemented Commented and STD output Revision History.");
		System.out.println();
		System.out.println(Driver.class.getName() + ".showRevisionHistory()... done!");
		System.out.println();
	}
}



// Output

//CSYE7374 Midterm July 2022 ...
//Store [name=Wollaston's, 
//itemList=[], 
// personList=[]]
//
//	neu.csye7374.Driver.showStoreOperationalStates()...
//Store is in Start State
//Store is in Stock State 
//Store is in Open State 
//Store is in Close State 
//Store is in Stock State 
//
//	neu.csye7374.Driver.showStoreOperationalStates()... done!
//
//	neu.csye7374.Driver.showStoreDiscountAlgorithms()...
//The price of Iphone 11 originally is :899.99
//Price of Same Iphone 11 on following days is :- 
//Received Discount of 15% on Iphone 11 on Sale's Day. Final price = 764.99
//Received Discount of 10% on Iphone 11 on President's Day. Final price = 809.99
//Received Discount of 25% on Iphone 11 on Christmas. Final Price = 674.99
//Received Discount of 5% on Iphone 11 in Clearance Sale. Final Price = 854.99
//Received Discount of 40% on Iphone 11 as Wholesaler's discount. Final Price = 539.99
//Received Discount of 12% on Iphone 11 as Member's Discount. Final Price = 791.99
//Received Discount of 30% on Iphone 11 as Liquidation Discount. Final Price = 629.99
//
//	neu.csye7374.Driver.showStoreDiscountAlgorithms()... done!
//
//	neu.csye7374.Driver.addEmployeesToStore()...
//
//	neu.csye7374.Driver.addEmployeesToStore()... done!
//
//	neu.csye7374.Driver.addItemsToStore()...
//Do you want to buy warrantee plan along with Wheat Bread? Press  0. No Warrantee Plan	 1. Basic Warrantee Plan	 2. Advance Warrantee Plan 
// 0
//Do you want to buy services along with Wheat Bread? Press  0. No Service	 1. Maintenance Service 	 2. Repair Service 
// 0
//Do you want to buy warrantee plan along with OJ? Press  0. No Warrantee Plan	 1. Basic Warrantee Plan	 2. Advance Warrantee Plan 
// 0
//Do you want to buy services along with OJ? Press  0. No Service	 1. Maintenance Service 	 2. Repair Service 
// 0
//Do you want to buy warrantee plan along with Microsoft Surface? Press  0. No Warrantee Plan	 1. Basic Warrantee Plan	 2. Advance Warrantee Plan 
// 2
//Do you want to buy services along with Microsoft Surface? Press  0. No Service	 1. Maintenance Service 	 2. Repair Service 
// 2
//Do you want to buy warrantee plan along with Skim Milk? Press  0. No Warrantee Plan	 1. Basic Warrantee Plan	 2. Advance Warrantee Plan 
// 0
//Do you want to buy services along with Skim Milk? Press  0. No Service	 1. Maintenance Service 	 2. Repair Service 
// 0
//
//	neu.csye7374.Driver.addItemsToStore()... done!
//
//	neu.csye7374.Driver.sortEmployeesID()...
//Sort employees by PERSON ID...
//Sort items by ITEM ID...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan], 
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan]], 
// personList=[
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false], 
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true]]]
//
//	neu.csye7374.Driver.sortEmployeesID()... done!
//
//	neu.csye7374.Driver.sortEmployeesLastName()...
//Sort employees by PERSON LAST NAME...
//Sort items by ITEM NAME...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan], 
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan], 
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan]], 
// personList=[
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false], 
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true]]]
//
//	neu.csye7374.Driver.sortEmployeesLastName()... done!
//
//	neu.csye7374.Driver.sortEmployeesFirstName()...
//Sort employees by PERSON FIRST NAME...
//Sort items by ITEM PRICE...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan], 
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan]], 
// personList=[
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false], 
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true]]]
//
//	neu.csye7374.Driver.sortEmployeesFirstName()... done!
//
//	neu.csye7374.Driver.sortEmployeesAgeYoungest()...
//Sort employees by PERSON AGE (YOUNGEST FIRST)...
//Sort items by ITEM Description...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan]], 
// personList=[
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false]]]
//
//	neu.csye7374.Driver.sortEmployeesAgeYoungest()... done!
//
//	neu.csye7374.Driver.sortEmployeesAgeOldest()...
//Sort employees by PERSON AGE (OLDEST FIRST)...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan]], 
// personList=[
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false], 
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true]]]
//
//	neu.csye7374.Driver.sortEmployeesAgeOldest()... done!
//
//	neu.csye7374.Driver.sortEmployeesHighestWage()...
//Sort employees by HIGHEST WAGE...
//Store [name=Wollaston's, 
//itemList=[
//Item [itemID=1, itemPrice=3.49, itemName=OJ, itemDescription=Florida Orange Juice with Calcium, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=3, itemPrice=1.49, itemName=Wheat Bread, itemDescription=Healthy 30 Calorie Wheat Bread, deliveryChoice=Delivery, warranteeChoice=No warrantee Plan], 
//Item [itemID=4, itemPrice=3049.96, itemName=Microsoft Surface, itemDescription=Microsoft Surface Tablet Warrantee Plan worth $349.99: Covers basic plan services + screen damage and motherboard damage,  Repair Service is Requested on: 2022-07-12, deliveryChoice=In-Store Pickup, warranteeChoice=Advance Warrantee Plan], 
//Item [itemID=2, itemPrice=2.49, itemName=Skim Milk, itemDescription=Vitamin D Fortified Skim Milk, deliveryChoice=Curb Side Service, warranteeChoice=No warrantee Plan]], 
// personList=[
//Employee [Person [id= 1, firstName= Bob, lastName= James, age= 31], wage= 15.99, isEmployed=true, isStudent=false], 
//Employee [Person [id= 2, firstName= Don, lastName= Hope, age= 27], wage= 14.99, isEmployed=true, isStudent=true], 
//Employee [Person [id= 3, firstName= James, lastName= Pope, age= 21], wage= 12.99, isEmployed=true, isStudent=true]]]
//
//	neu.csye7374.Driver.sortEmployeesHighestWage()... done!
//
//neu.csye7374.Driver.showRevisionHistory()...
//
//1.0 Implemented skeleton classes for Person, Employee
//1.1 Created Sellable interface and StoreAPI interface
//1.2 Implemented skeleton classes for Item implementing SellableAPI and Store implementing StoreAPI
//1.3 Created AbstractFactory interface for Employee and Item Singleton Factory and implemented ItemBuilder and EmployeeBuilder
//1.4 Fixed bug in getEmployee() in EmployeeBuilder and similar methods in ItemBuilder by changing the references employee and Item objects 
//1.5 Completed the code to add Employees and Items in Store
//1.6 Completed the code of various sort methods for Employees and Items
//1.7 Fixed the bug in the code of various sort methods for Items as its List was of type SellableAPI
//2.0 Started implementation of State, Strategy, Decorator, Prototype
//2.1 Fixed bug in Decorator Pattern to pass item Object with decoration
//2.2 Fixed bug in discount method of Strategy pattern to show the implementation of Strategy pattern 
//2.3 Completed Implementation for design pattern State,Decorator, Strategy ...
//2.4 Started Implementation for design pattern Prototype
//2.5 Fixed bug in the ServiceCache Conrete class
//2.6 Completed Implementation for design pattern Prototype
//3.0 Implemented Commented and STD output Revision History.
//
//neu.csye7374.Driver.showRevisionHistory()... done!
//
//CSYE7374 Midterm July 2022 ... done!
