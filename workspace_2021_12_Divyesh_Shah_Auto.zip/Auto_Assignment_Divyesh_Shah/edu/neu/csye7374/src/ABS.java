package neu.csye7374.src;

public class ABS extends AutoDecorator {

	public ABS(AutoAPI autoAPI) {
		super(autoAPI);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return autoAPI.getPrice()+26.89;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return autoAPI.getDescription() +"\nDecorated with Anti Braking System";
	}

}
