package neu.csye7374.src;

import java.util.Scanner;

public class SportyCoupeAuto implements AutoAPI {
	
	

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 30000;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "This is SportyCoupeAuto ";
	}
	
	
	public static void demo() {
		Scanner s=new Scanner(System.in);
		int i;
		for(int j=0;j<3;j++) { // loop to display 3 different test cases
			AutoAPI autoAPI=new SportyCoupeAuto(); // base auto Class
				System.out.println("Modify your Auto with options of your choice:-");
				System.out.println("1. Air Conditioning \n2.All wheel Drive \n3.Anti Braking System \n4.Bumper to Bumper Warrantee \n5.Blind-Side Detection Monitor \n-1 No Modification\n");
				System.out.print("Enter your choice:- ");
				i=s.nextInt();
				System.out.println();
				while(i!=-1) {
					if(i==1)
						autoAPI=new AC(autoAPI);	// When decorating with AC class
					else if(i==2)
						autoAPI=new AWD(autoAPI);	// When decorating with AWD class
					else if(i==3)
						autoAPI=new ABS(autoAPI);	// When decorating with ABS class
					else if(i==4)
						autoAPI=new BB(autoAPI);	// When decorating with BB class
					else if(i==5)
						autoAPI=new BDM(autoAPI);	// When decorating with BDM class
					else
						System.out.println("xxxxxx Wrong Choice xxxxx \t Please input correct choice");
					System.out.println("Do you want more more modification: If \"Yes\" then select the option or else press -1");
					i=s.nextInt();  // To take next user choice input
				}
			
			
			System.out.println("\nThe total_cost after Modifications is: "+ autoAPI.getPrice());
			System.out.println("The final modified car with description as follows:-\n"+autoAPI.getDescription());		
			System.out.println("-------------------------------------------------------------------------");
		}
			// Another way to decorated base Auto Class by wrapping with decorators.
			AutoAPI modified_AUTO=new BDM(new ABS(new AC(new SportyCoupeAuto())));
			System.out.println("The total_cost after Modifications is: "+ modified_AUTO.getPrice());
			System.out.println(modified_AUTO.getDescription());
		
		}
		
	
	

}
