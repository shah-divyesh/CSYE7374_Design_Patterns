package neu.csye7374.src;

public interface AutoAPI {
	double getPrice();
	String  getDescription();
}
