package neu.csye7374.src;

public class BDM extends AutoDecorator {

	public BDM(AutoAPI autoAPI) {
		super(autoAPI);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return autoAPI.getPrice()+ 250;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return autoAPI.getDescription() +"\nDecorated with Blind-Side Detection Monitor";
	}

}
