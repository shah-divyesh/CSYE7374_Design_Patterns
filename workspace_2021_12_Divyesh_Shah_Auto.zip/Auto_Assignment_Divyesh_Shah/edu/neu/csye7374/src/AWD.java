package neu.csye7374.src;

public class AWD extends AutoDecorator {

	public AWD(AutoAPI autoAPI) {
		super(autoAPI);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return autoAPI.getPrice()+50.5;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return autoAPI.getDescription() +"\nDecorated with all wheel drive";
	}

}
