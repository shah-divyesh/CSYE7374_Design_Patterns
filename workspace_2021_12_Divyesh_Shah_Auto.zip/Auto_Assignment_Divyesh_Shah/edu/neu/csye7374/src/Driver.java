package neu.csye7374.src;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SportyCoupeAuto.demo();
	}

}


//Modify your Auto with options of your choice:-
//1. Air Conditioning 
//2.All wheel Drive 
//3.Anti Braking System 
//4.Bumper to Bumper Warrantee 
//5.Blind-Side Detection Monitor 
//-1 No Modification
//
//Enter your choice:- 1
//
//Do you want more more modification: If "Yes" then select the option or else press -1
//2
//Do you want more more modification: If "Yes" then select the option or else press -1
//3
//Do you want more more modification: If "Yes" then select the option or else press -1
//-1
//
//The total_cost after Modifications is: 30177.39
//The final modified car with description as follows:-
//This is SportyCoupeAuto 
//Decorated with Air Conditioning
//Decorated with all wheel drive
//Decorated with Anti Braking System
//-------------------------------------------------------------------------
//Modify your Auto with options of your choice:-
//1. Air Conditioning 
//2.All wheel Drive 
//3.Anti Braking System 
//4.Bumper to Bumper Warrantee 
//5.Blind-Side Detection Monitor 
//-1 No Modification
//
//Enter your choice:- 2
//
//Do you want more more modification: If "Yes" then select the option or else press -1
//3
//Do you want more more modification: If "Yes" then select the option or else press -1
//4
//Do you want more more modification: If "Yes" then select the option or else press -1
//9
//xxxxxx Wrong Choice xxxxx 	 Please input correct choice
//Do you want more more modification: If "Yes" then select the option or else press -1
//2
//Do you want more more modification: If "Yes" then select the option or else press -1
//-1
//
//The total_cost after Modifications is: 30203.14
//The final modified car with description as follows:-
//This is SportyCoupeAuto 
//Decorated with all wheel drive
//Decorated with Anti Braking System
//Decorated with Bumper to Bumper warrantee
//Decorated with all wheel drive
//-------------------------------------------------------------------------
//Modify your Auto with options of your choice:-
//1. Air Conditioning 
//2.All wheel Drive 
//3.Anti Braking System 
//4.Bumper to Bumper Warrantee 
//5.Blind-Side Detection Monitor 
//-1 No Modification
//
//Enter your choice:- 5
//
//Do you want more more modification: If "Yes" then select the option or else press -1
//1
//Do you want more more modification: If "Yes" then select the option or else press -1
//3
//Do you want more more modification: If "Yes" then select the option or else press -1
//-1
//
//The total_cost after Modifications is: 30376.89
//The final modified car with description as follows:-
//This is SportyCoupeAuto 
//Decorated with Blind-Side Detection Monitor
//Decorated with Air Conditioning
//Decorated with Anti Braking System
//-------------------------------------------------------------------------
//The total_cost after Modifications is: 30376.89
//This is SportyCoupeAuto 
//Decorated with Air Conditioning
//Decorated with Anti Braking System
//Decorated with Blind-Side Detection Monitor