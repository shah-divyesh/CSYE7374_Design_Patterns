package neu.csye7374.src;

public class AC extends AutoDecorator {
	

	public AC(AutoAPI autoAPI) {
		super(autoAPI);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return autoAPI.getPrice()+100;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return  autoAPI.getDescription() +"\nDecorated with Air Conditioning";
	}

}
