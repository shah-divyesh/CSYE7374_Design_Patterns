package neu.csye7374.src;

import neu.csye7374.src.AdapterPattern.PaymentAPI;
import neu.csye7374.src.AdapterPattern.PaymentAdapter;

public interface Tradable  {
	PaymentAdapter paymentAdapter=null;
	public void setBid(double Price);
	public  int getMetric();
	
//	@Override
//	default void makePayment(String paymentType, double amount) {
//		// TODO Auto-generated method stub
//		if(paymentType.equalsIgnoreCase("mp3")){
//			System.out.println("####### Making a payment of $"+amount+" through Cheque #########");		
//	      } 
//	      
//	      //mediaAdapter is providing support to play other file formats
//	      else if(paymentType.equalsIgnoreCase("googlepay") || paymentType.equalsIgnoreCase("mp4")){
//	    	 paymentAdapter = new PaymentAdapter(paymentType);
//	    	 paymentAdapter.play(amount);
//	      }
//	      
//	      else{
//	         System.out.println("Invalid media. " + paymentType + " format not supported");
//	      }
//		
//	}
}
