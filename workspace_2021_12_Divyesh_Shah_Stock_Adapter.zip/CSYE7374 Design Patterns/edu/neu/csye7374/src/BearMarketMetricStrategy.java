package neu.csye7374.src;

import java.util.concurrent.ThreadLocalRandom;

public class BearMarketMetricStrategy implements MetricStrategyAPI {

	@Override
	public int calculateMetric() {
		// TODO Auto-generated method stub
		int num = (int)((ThreadLocalRandom.current().nextInt( -40 + 1,0)*2.5)/2.99);
		return num;
	}

}

