package neu.csye7374.src;

@FunctionalInterface
public interface MetricStrategyAPI {
	int calculateMetric();
}
