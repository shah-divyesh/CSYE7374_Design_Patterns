package neu.csye7374.src.AdapterPattern;

public class ApplePay implements DigitalPaymentAPI{

private static ApplePay applePayInstance=new ApplePay();
	
	private ApplePay() {}
	
	public static ApplePay getInstance() {
		return applePayInstance;
	}
	
	@Override
	public void makeDigitalPayment(double amount) {
		// TODO Auto-generated method stub
		System.out.println("########################### Making a payment of $"+amount+" through ApplePay #############################");
	}

}
