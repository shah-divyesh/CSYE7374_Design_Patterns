package neu.csye7374.src.AdapterPattern;

public class GooglePay implements DigitalPaymentAPI {

	private static GooglePay googlePayInstance;
	
	private GooglePay(){
		super();
		googlePayInstance=null;
	}
	
	public static synchronized GooglePay getInstance() {
		if (googlePayInstance == null) {
			googlePayInstance = new GooglePay();
		}
		return googlePayInstance;
	}
	
	@Override
	public void makeDigitalPayment(double amount) {
		// TODO Auto-generated method stub
		System.out.println("---------------------------Making a payment of $"+amount+" through GooglePay---------------------------");
	}
}
