package neu.csye7374.src.AdapterPattern;

public interface DigitalPaymentAPI {
	public void makeDigitalPayment(double amount);
}
