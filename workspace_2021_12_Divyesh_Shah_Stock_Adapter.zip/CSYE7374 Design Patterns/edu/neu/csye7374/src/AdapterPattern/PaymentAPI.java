package neu.csye7374.src.AdapterPattern;

public interface PaymentAPI {
	public void makePayment(String paymentType, double amount);
}
