package neu.csye7374.src.AdapterPattern;

public class PaymentAdapter implements PaymentAPI {
	
	DigitalPaymentAPI digitalPaymentAPI;
	
	public PaymentAdapter(String paymentType) {
		if(paymentType.equalsIgnoreCase("googlepay") ){
			digitalPaymentAPI = GooglePay.getInstance();			
        }
		else if (paymentType.equalsIgnoreCase("applepay")){
			digitalPaymentAPI = ApplePay.getInstance();
		}	
	}

	@Override
	public void makePayment(String paymentType, double amount) {
		// TODO Auto-generated method stub
		digitalPaymentAPI.makeDigitalPayment(amount);		
	}
}
