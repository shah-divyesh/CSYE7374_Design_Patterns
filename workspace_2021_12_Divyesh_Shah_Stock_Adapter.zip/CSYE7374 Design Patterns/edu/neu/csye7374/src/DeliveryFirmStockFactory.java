package neu.csye7374.src;

public class DeliveryFirmStockFactory extends AbstractFirmStockFactory{

	@Override
	public StockAPI getObject(String ID, double price, String description, double bid, String tradeType) {
		// TODO Auto-generated method stub
		return new DeliveryFirmStocks(ID,price,description,bid,tradeType);
	}

}
