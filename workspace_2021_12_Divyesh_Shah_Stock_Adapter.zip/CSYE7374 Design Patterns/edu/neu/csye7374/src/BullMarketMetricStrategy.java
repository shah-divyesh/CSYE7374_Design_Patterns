package neu.csye7374.src;

import java.util.concurrent.ThreadLocalRandom;

public class BullMarketMetricStrategy implements MetricStrategyAPI {

	@Override
	public int calculateMetric() {
		// TODO Auto-generated method stub
		int num = (int)((ThreadLocalRandom.current().nextInt(1, 40 + 1)*2.5)/2.99);
		return num;
	}

}
