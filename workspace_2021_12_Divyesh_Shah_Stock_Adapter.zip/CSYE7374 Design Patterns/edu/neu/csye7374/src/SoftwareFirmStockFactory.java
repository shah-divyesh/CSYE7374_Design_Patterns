package neu.csye7374.src;

public class SoftwareFirmStockFactory  extends AbstractFirmStockFactory {

	@Override
	public StockAPI getObject(String ID, double price, String description, double bid, String tradeType) {
		// TODO Auto-generated method stub
		return new SoftwareFirmStocks(ID,price,description,bid,tradeType);
	}

}
