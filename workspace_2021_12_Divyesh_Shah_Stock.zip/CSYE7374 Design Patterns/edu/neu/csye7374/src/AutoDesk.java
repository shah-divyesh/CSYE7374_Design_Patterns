package neu.csye7374.src;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class AutoDesk extends StockAPI{

	
	
	public AutoDesk(String iD, double price, String description, double bid, String tradeType) {
		super(iD, price, description, bid, tradeType);
		// TODO Auto-generated constructor stub
	}

	public double getBid() {
		int randNum=ThreadLocalRandom.current().nextInt(130, 200 + 1);
		return randNum;
	}
	
	@Override
	public void setBid(double Price) {
		// TODO Auto-generated method stub
		super.setBid(Price);
	}

	@Override
	public int getMetric() {
		// TODO Auto-generated method stub
		int num = (ThreadLocalRandom.current().nextInt(-40, 40 + 1)*5)/4;
		return num;
	}


}
