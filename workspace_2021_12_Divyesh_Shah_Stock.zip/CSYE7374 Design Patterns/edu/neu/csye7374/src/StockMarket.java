/**
 * 
 */
package neu.csye7374.src;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jyoti
 *
 */
public class StockMarket {

	private static StockMarket instance;
	private List<StockAPI> stocks= new ArrayList<>();
	private List<StockAPI> tradedstocks=new ArrayList<>();
	
	
	public List<StockAPI> getStocks() {
		return stocks;
	}

	public void setStocks(List<StockAPI> stocks) {
		this.stocks = stocks;
	}

	public List<StockAPI> getTradedstocks() {
		return tradedstocks;
	}

	public void setTradedstocks(List<StockAPI> tradedstocks) {
		this.tradedstocks = tradedstocks;
	}

	public static StockMarket getInstance() {
			if (instance == null) {
				instance = new StockMarket();
			}
			return instance;
		   }

	   public void addStock(StockAPI s)
	   {
		   getStocks().add(s);
	   }
	   public void removeStock(StockAPI s)
	   {
		   getStocks().remove(s);
	   }
	   
	   public void addTrade(StockAPI s)
	   {
		   tradedstocks.add(s);
	   } 
	   
	   public void showTrades()
	   {
		   System.out.println("Traded stocks Now...");
		   for (StockAPI t : tradedstocks)
		    {System.out.println(t.getID()+":"+t.getTradeType()+" at price:"+t.getPrice());}
	   } 
	   
	   public void showStocks()
	   {
		   System.out.println("Stock Market Now...");
		   for (StockAPI s : getStocks())
		    {System.out.println(s.toString());}
	   }
	   
	   public void trade(StockAPI s)
	   {
		  if (s.getMetric()>0)
		  {
			  if (s.getBid() >= s.getPrice() )  // consider buying as stock shows positive performance 
			  {
				  StockAPI  tradebuystock = new StockAPI(s.getID(),s.getPrice(),s.getDescription(),s.getBid(),s.getTradeType());
				  tradebuystock.setTradeType("Buying");
				  addTrade(tradebuystock);
			  }
		  }
		  else // consider selling as stock shows negative performance 
			  {
			  StockAPI  tradesellstock = new StockAPI(s.getID(),s.getPrice(),s.getDescription(),s.getBid(),s.getTradeType());
			  tradesellstock.setTradeType("Selling");
			  addTrade(tradesellstock);
			  	}	 
		  
		  s.setPrice(s.getPrice()+s.getMetric());
	   }
	   
	   
	   /**
	    *
	    *
A. Add Stock objects;

B. Trade Stock objects (calculate new Stock price based on current price, bid and metric);

C. Remove Stock objects;

D. Show all stocks traded on this market (e.g., Stock state like price, metric, etc.)

	    */
	   
	   
	   
}
	
