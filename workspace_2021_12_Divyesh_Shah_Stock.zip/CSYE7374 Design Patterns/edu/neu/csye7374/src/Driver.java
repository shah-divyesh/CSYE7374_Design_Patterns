package neu.csye7374.src;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class Driver {

	public static void main(String[] args) {
		//creating market
		StockMarket SM = StockMarket.getInstance();
		System.out.println("Stocks: ");
		SM.showStocks();
		System.out.println("TradedStocks: ");
		SM.showTrades();
		
		//adding few stocks
		StockAPI s1 = new UPS("United Postal Service",230.0,"UPS Common Stock",0.0,null);
		StockAPI s2 = new AutoDesk("AutoDesk",170.0,"AutoDesk COmmon Share",0.0,null);
		
		
		SM.addStock(s1);
		SM.addStock(s2);
		
		//viewing stocks
		System.out.println("First display of stock market");
		SM.showStocks();
		
		System.out.println("--------------------------------------------------------------------");	
		// simulation of trading on s1
		for (int i=0; i<7; i++)
		{
			double start = s1.getPrice();
			double end = s1.getPrice()+s1.getMetric();
			double random = new Random(System.currentTimeMillis()+9).nextDouble();
			double bid_now = start + (random * (end - start));
			System.out.println("Bidding on UPS: "+bid_now);
			System.out.println("After bid on UPS of stock market");
			s1.setBid(bid_now);
			SM.showStocks();
			System.out.println("After trade on UPS of stock market");
			SM.trade(s1);
			SM.showTrades();	
		}
		
		System.out.println("--------------------------------------------------------------------");
		// simulation of trading on s2
		for (int i=0; i<7; i++)
		{
			double start = s2.getPrice();
			double end = s2.getPrice()+s2.getMetric();
			double random = new Random(System.currentTimeMillis()+7).nextDouble();
			double bid_now = start + (random * (end - start));
			System.out.println("Bidding on AutoDesk: "+bid_now);
			System.out.println("After bid on AutoDesk of stock market");
			s2.setBid(bid_now);
			SM.showStocks();
			System.out.println("After trade on AutoDesk of stock market");
			SM.trade(s2);
			SM.showTrades();	
		}
		System.out.println("--------------------------------------------------------------------");

		System.out.println("End of day Display of stock market");
		SM.showStocks();
		System.out.println("End of day trades executed");
		SM.showTrades();
		
 }
}
	
